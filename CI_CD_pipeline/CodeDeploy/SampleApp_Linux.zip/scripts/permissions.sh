#!/bin/bash
sudo chmod -R 755 /var/www/html